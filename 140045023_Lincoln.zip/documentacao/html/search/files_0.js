var searchData=
[
  ['string_5fsoma_2ec',['string_soma.c',['../string__soma_8c.html',1,'']]],
  ['string_5fsoma_2eh',['string_soma.h',['../string__soma_8h.html',1,'']]]
];
