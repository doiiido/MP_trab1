var searchData=
[
  ['testa_5fstring_5fsoma_2ec',['testa_string_soma.c',['../testa__string__soma_8c.html',1,'']]],
  ['testa_5fstring_5fsoma_5fstdin_2ec',['testa_string_soma_stdin.c',['../testa__string__soma__stdin_8c.html',1,'']]]
];
