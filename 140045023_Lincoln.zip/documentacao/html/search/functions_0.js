var searchData=
[
  ['main',['main',['../testa__string__soma__stdin_8c.html#ae66f6b31b5ad750f1fe042a706a4e3d4',1,'testa_string_soma_stdin.c']]],
  ['matches_5fnext',['matches_next',['../string__soma_8c.html#a3176cf583cc7a74ae2afe060ad2a4bab',1,'string_soma.c']]]
];
